#include <iostream>

using namespace std;

int main() {
  //PART ! ------------
  /* 
  MANSFIELD, TX
  city 1 day 1: 69
  cit 1,day 2: 75
  cit 1,day 3:61
  cit 1,day 4:67
  cit 1,day 5:73
  cit 1,day 6:78
  cit 1,day 7:81
  SEATTLE, WA
  city 2 day 1:60
  cit 2,day 2:52
  cit 2,day 3:57
  cit 2,day 4:55
  cit 2,day 5:52
  cit 2,day 6:58
  cit 2,day 7:60
  */

  //pre-populated arrays that I will display using for loop
  int cityOne[7] = {75,61,67,73,78,81}; //city 1 and their temperatures
  int cityTwo[7] = {60,52,57,55,52,58,60}; //city 2 and their temperatures
  for(int i = 0; i < 7; i++)
    {
      cout << "Mansfield 1 Day " << i+1 << ": " << cityOne[i] << endl;
      
    }
  for(int i = 0; i < 7; i++)
    {
      cout << "Seattle 2 Day " << i+1 << ": " << cityTwo[i] << endl;
      
    }
  
  //PART 2 ------------
  //user will input their temperatures of chosen city into the array
  const int CITY = 2;
  const int WEEK = 7;

  int temperature[CITY][WEEK];
  cout<< "Enter all temperature for a week of first city and then second city. \n";

   for(int i = 0; i<CITY;i++)
    {
      string city_name;
      for(int j = 0; j<WEEK;j++)
        {
          cout<<"City "<<i+1<<", Day "<<j+1<<": ";
          cin>> temperature[i][j];
        }
    }

  //printing the city-temperature array
  cout << "\n\nDisplaying Values:\n";

  for(int d =0; d<CITY;d++)
    {
      for (int z = 0; z<WEEK; z++)
        {
          cout<<"City "<<d+1<<", Day "<<z+1<< " = "<<temperature[d][z]<<endl;
         
        }
    }
  //EXTRA CREDIT ------------
  int cityOne_extra[7] = {75,61,67,73,78,81,85}; //city 1 and their temperatures
  int cityTwo_extra[7] = {60,52,57,55,52,58,60}; //city 2 and their temperatures

  //feeding both arrays into temperature[]
  for(int i = 0; i < CITY; i++)
    {
      for(int j = 0; j < WEEK; j++)
        {
          if (i == 0) {
            temperature[i][j] = cityOne_extra[j];
          } else if (i == 1) {
            temperature[i][j] = cityTwo_extra[j];
          }
        }
    }
  //printing the city-temperature array
  cout << "\n\nDisplaying New Array(EXTRA CREDIT):\n";
  for(int d =0; d<CITY;d++)
    {
      for (int z = 0; z<WEEK; z++)
        {
          cout<<"City "<<d+1<<", Day "<<z+1<< " = "<<temperature[d][z]<<endl;
            
        }
    }
  return 0;
}