#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <utility>
#include <vector>
using namespace std;

bool less_than_7(int value) { return value < 7; }
// cosc 1437 vector_as_class_member
class myClass {
private:
  vector<int> vecI;

public:
  myClass(vector<int> v) // perameterized constructor
  {
    vecI = v;
  }
  void print() // print the elements of the vector
  {
    for (const int &element : vecI) {
      cout << element << " ";
    }
    cout << "\n";
  }
};

int main(int argc, char *argv[]) {
  // cosc 1437 vectors
  vector<double> vd; // vd is a vector of doubles
  vector<int> vi;    // vector of integers
  vector<string> vs; // vs is a vector of strings

  // add 3 elements to the vector of doubles
  vd.push_back(1.567);
  vd.push_back(2.315);
  vd.push_back(3.14159);

  // add 3 elements to the vector of integers
  vi.push_back(1);
  vi.push_back(2);
  vi.push_back(3);

  // add 3 elements to the vector of strings
  vs.push_back("Hello");
  vs.push_back("howdy");
  vs.push_back("hola");

  // display the 3 elements in the vector of doubles

  // For vector of doubles
  for (const double &element : vd) {
    cout << element << " ";
  }
  cout << "\n";

  // For vector of integers
  for (const int &element : vi) {
    cout << element << " ";
  }
  cout << "\n";

  // For vector of strings
  for (const string &element : vs) {
    cout << element << "\n";
  }
  // using class to create and print a vector
  vector<int> vLocal = {1, 2, 3};
  myClass test(vLocal);
  test.print();

  // section 3 iterators
  vector<int> vint(10);
  vint[0] = 10;
  vint[1] = 20;
  vint[2] = 30;
  vint[3] = 40;
  vint[4] = 50;
  vint[5] = 60;
  vint[6] = 70;
  vint[7] = 80;
  vint[8] = 90;
  vint[9] = 100;

  // display elements of vector
  vector<int>::iterator it;
  for (it = vint.begin(); it != vint.end(); ++it) {
    cout << " " << *it;
  }
  // cosc 1437 STACK

  stack<int> st;

  st.push(100);               // push number on the stack
  assert(st.size() == 1);     // verify one element is on the stack
  assert(st.top() == 100);    // verify element value
  st.top() = 456;             // assign new value
  assert(st.top() == 456);    // verify element value
  st.pop();                   // remove element
  assert(st.empty() == true); // verify stack is empty

  // COSC 1437/ Set
  set<int> iset; // set of unique integer numbers

  // populate with values
  iset.insert(11);
  iset.insert(-11);
  iset.insert(55);
  iset.insert(22);
  iset.insert(22);
  if (iset.find(55) != iset.end()) // is value already stored?
  {
    iset.insert(55); // if not then insert it
  }
  assert(iset.size() == 4);                          // verify size
  set<int>::iterator it2;                            // create iterator
  for (it2 = iset.begin(); it2 != iset.end(); ++it2) // print values
  {
    cout << " " << *it2;
  }

  // COSC 1437/ Pair Structure
  pair<string, string> strstr; // a pair with 2 elements
  strstr.first = "Hello";      // first element
  strstr.second = "World";

  pair<int, string> intstr; // a pair with 2 elements
  intstr.first = 1;         // first element
  intstr.second = "one";

  pair<string, int> strint("two", 2); // a pair with 2 elements
  assert(strint.first == "two");      // verify contents
  assert(strint.second == 2);         // verify contents

  // cosc 1437/ Map
  map<string, string> phone_book;                 // a map of strings
  phone_book["411"] = "Directory";                // assign value to 411 number
  phone_book["911"] = "Emergency";                // assign value to 911 number
  phone_book["508-678-2811"] = "BCC";             // assign value to 508 number
  if (phone_book.find("411") != phone_book.end()) // is value already stored?
  {
    phone_book.insert(
        make_pair(string("411"), string("Directory"))); // if not then insert it
  }
  assert(phone_book.size() == 3);          // verify size is 3
  map<string, string>::const_iterator it3; // create iterator
  for (it3 = phone_book.begin(); it3 != phone_book.end(); ++it3) // print values
  {
    cout << " " << it3->first << " " << it3->second << "\n";
  }

  // COSC 1437/ sort algorithm
  int arr[100];               // create array
  sort(arr, arr + 100);       // sort the array
  vector<int> v1;             // create vector
  sort(v1.begin(), v1.end()); // sort the vector

  // COSC 1437/ predicate algorithm
  // NOTE couldnt get this to work because of unused variable count_less but the
  // code is there
  // vector<int> v2; //create vector
  // int count_less = count_if(v2.begin(), v2.end(), less_than_7);//count_if
  // returns the number of elements that are less than 7
  return 0;
}