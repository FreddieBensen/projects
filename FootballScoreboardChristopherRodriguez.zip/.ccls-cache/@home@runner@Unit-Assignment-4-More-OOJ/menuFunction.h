/im making this file so i can insert my extensive menu function in here cause its ugly
#include <iostream> 
using namespace std;

