
#include <ios>  
#include <iostream>  
#include<sstream>
#include"classes.h"
using namespace std; 



template <typename T>
T getValidatedInput()
{
    
    T result;
    cin >> result;

    
    if (cin.fail() || cin.get() != '\n')
    {
        
        cin.clear();

        
        while (cin.get() != '\n')
            ;

        
        throw ios_base::failure("Invalid input.");
    }

    return result;
}

//Function Definitions
int validateInt(int &intInput)
{
  while (true)
    {
        cout << "Enter an integer: ";

        try
        {
            intInput = getValidatedInput<int>();
        }
        catch (exception e)
        {
           cout<<"Invalid input. Please enter an integer."<<endl;
            continue;
        }

        break;
    }

    return intInput; 
}

double validateDouble(double &doubleInput)
{
  while (true)
    {
        cout << "Enter a number with or without decimals (double): ";

        try
        {
            doubleInput = getValidatedInput<double>();
        }
        catch (exception e)
        {
            cout<<"Invalid input. Please enter a number with or without decimals (double)."                   <<endl;
            continue;
        }

        break;
    }

    return doubleInput; 
}

char validateChar(char &charInput)
{ 
    while (true)
    {
        cout << "Enter a single letter or number (1 digit): ";

        try
        {
            charInput = getValidatedInput<char>();
        }
        catch (exception e)
        {
            cout<<"Invalid input. Please enter a single letter or number (1 digit)."<<endl;
            continue;
        }

        break;
    }

    return charInput; 
}

string validateString(string &stringInput)
{
    while (true) //use cin, getline() for this 
    {
       // cout << "Enter a word (no spaces): ";

        try
        {
            stringInput  = getValidatedInput<string>();
        }
        catch (exception e)
        {
           cout<<"Invalid input. Please enter a word (no spaces)."<<endl;
            continue;
        }

        break;
    }

    return stringInput; 
}



//function for my menu
void menuChoice(int userInput, scoreboard &s)
{
  string teamName = " ";
  string coachName = " ";
  bool ballPossession;
  switch(userInput)
      {
        case 1:
        cout << "\n Update Home Team Score: ";
        validateInt(userInput);
        s.setHomeScore(userInput);
        break;
        case 2:
        cout << "\n Update Away Team Score: ";
        validateInt(userInput);
        s.setAwayScore(userInput);
        break;
        case 3:
        cout << "\n Update Down: ";
        validateInt(userInput);
        s.setDown(userInput);
        break;
        case 4:
        cout << "\n Update To Go: ";
        validateInt(userInput);
        s.setToGo(userInput);
        break;
        case 5:
        cout << "\n Update Quarter: ";
        validateInt(userInput);
        s.setQuarter(userInput);
        break;
        case 6:
        cout << "\n Update Time: ";
        cout<<" \n Minute: ";
        validateInt(userInput);
        if(validateInt(userInput) <= 59) //make sure it is in the right range
        {
          s.setMinute(userInput);
        }
        cout<<" \n Second: ";
        validateInt(userInput);
        if(validateInt(userInput) <= 15)
        {
          s.setSecond(userInput);
        }
        break;
        case 7:
        cout << "\n Update Home Team Name: ";
        validateString(teamName);
        s.setHomeName(teamName);
        break;
        case 8:
        cout << "\n Update Away Team Name: ";
        validateString(teamName);
        s.setAwayName(teamName);
        break;
        case 9:
        cout << "\n Update Home Team Coach Name: ";
        validateString(coachName);
        s.setHomeCoachName(coachName);
        break;
        case 10:
        cout << "\n Update Away Team Coach Name: ";
        validateString(coachName);
        s.setAwayCoachName(coachName);
        break;
        case 11:
        cout << "\n Update Team Possession 1 for HOME and 0 for AWAY : ";
        validateInt(userInput);
        while(true){
        if(userInput == 1)
        {
          s.sethomePossession(true);
        }
        else if(userInput == 0)
        {
          s.setAwayPossession(false);
        }
        else{
          cout<<"Invalid input. Please enter 1 for HOME and 0 for AWAY."<<endl;
        }}
        break;
        //HERE ______________________________________________________________
        case 0:
        cout << "\n Hasta La vista Baby!";
        exit(0);
        break;
        default:
        cout << "\n Invalid Input"<<endl;
        break;

      }


  }

