//file to hold classes because its overwhelming on my screen
#include <iostream>
using namespace std;

class team {
private:
  string name;
  string coachName;
  bool homeStatus; // is home or away?
  int score;
  int timeout_count;
  bool possession; // who has the ball
public:
  void setName(string n) { name = n; };
  void setCoachName(string cn) { coachName = cn; }
  void setHomeStatus(bool hs) { homeStatus = hs; }
  void setScore(int s) { score = s; }
  void setTimeoutCount(int tc) { timeout_count = tc; }
  void setPossession(bool p) { possession = p; }

  string getName() const { return name; }
  string getCoachName() const { return coachName; }
  bool getHomeStatus() const { return homeStatus; }
  int getScore() const { return score; }
  int getTimeoutCount() const { return timeout_count; }
  bool getPossession() const { return possession; }
};

class scoreboard {
private:
  int down;
  int toGo;
  int quarter;
  int minute;
  int second;

  

public:
  team home;
  team away;
   
  scoreboard() 
  { // default constructor
    down = 1;
    toGo = 10;
    quarter = 1;
    minute = 15;
    second = 00;
    home.setScore(0);
    away.setScore(0);
    home.setPossession(true);
    away.setPossession(false);
    away.setName("defaultName ");
    home.setName("defaultName ");
    home.setCoachName("defaultCoachName ");
    away.setCoachName("defaultCoachName ");
    down = 1;
    toGo = 10;
    quarter = 1;
    minute = 15;
    second = 00;
  }
  void setDown(int d) { down = d; }
  void setToGo(int tg) { toGo = tg; }
  void setQuarter(int q) { quarter = q; }
  void setMinute(int m) { minute = m; }
  void setSecond(int s) { second = s; }
  void sethomePossession(bool hp) { home.setPossession(hp); }
  void setAwayPossession(bool ap) { away.setPossession(ap); }
  void setHomeScore(int hs){home.setScore(hs);}
  void setAwayScore(int as){away.setScore(as);}
  void setHomeName(string hn){home.setName(hn);}
  void setAwayName(string an){away.setName(an);}
  void setHomeCoachName(string hcn){home.setCoachName(hcn);}
  void setAwayCoachName(string acn){away.setCoachName(acn);}


  int getDown() const { return down; }
  int getToGo() const { return toGo; }
  int getQuarter() const { return quarter; }
  int getMinute() const { return minute; }
  int getSecond() const { return second; }
  int getHomeScore() const { return home.getScore(); }
  int getAwayScore() const { return away.getScore(); }
  string getHomeName() const { return home.getName(); }
  string getAwayName() const { return away.getName(); }
  string getHomeCoachName() const { return home.getCoachName(); }
  string getAwayCoachName() const { return away.getCoachName(); }

  void showScoreboard() 
  {
    int width = 60; // Width of the scoreboard for borders
    string topAndBottomBorder = string(width, '*'); // Creates a string of '*' characters
    string sideBorders = "|" + string(width - 2, ' ') + "|"; // Creates side borders
    cout << topAndBottomBorder << endl;
    cout << sideBorders << endl; // Print top side border


    // Now, print the actual scoreboard content with side borders at each line.
    cout << "| "<<home.getName();
    cout<<"\t\t"<<minute<<':'<<second;
    cout<<" \t\t\t"<<away.getName()<<endl;;
    cout<<"| Score: "<<home.getScore();
    cout<<"\t\t QTR: "<<quarter;
    cout<<"\t\t\tScore: "<<away.getScore()<<"\t\t\t\t   "<<endl;
    cout<<"| Down: "<<down;


    string possessionIndicator = home.getPossession() ? "\tHome has ball " : "\tAway has ball ";
    cout << "\t" << possessionIndicator;
    cout << "\tTo Go: " << getToGo() << " \t\t\t\t   |" << endl;
    cout << sideBorders << endl; // Print bottom side border
    cout << topAndBottomBorder << endl;
  }
};
