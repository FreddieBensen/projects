
#include <ios>  
#include <iostream>  
#include<sstream>
#include"classes.h"
using namespace std; 



template <typename T>
T getValidatedInput()
{
    
    T result;
    cin >> result;

    
    if (cin.fail() || cin.get() != '\n')
    {
        
        cin.clear();

        
        while (cin.get() != '\n')
            ;

        
        throw ios_base::failure("Invalid input.");
    }

    return result;
}

//Function Definitions
int validateInt(int &intInput)
{
  while (true)
    {
        cout << "Enter an integer: ";

        try
        {
            intInput = getValidatedInput<int>();
        }
        catch (exception e)
        {
           cout<<"Invalid input. Please enter an integer."<<endl;
            continue;
        }

        break;
    }

    return intInput; 
}

double validateDouble(double &doubleInput)
{
  while (true)
    {
        cout << "Enter a number with or without decimals (double): ";

        try
        {
            doubleInput = getValidatedInput<double>();
        }
        catch (exception e)
        {
            cout<<"Invalid input. Please enter a number with or without decimals (double)."                   <<endl;
            continue;
        }

        break;
    }

    return doubleInput; 
}

char validateChar(char &charInput)
{ 
    while (true)
    {
        cout << "Enter a single letter or number (1 digit): ";

        try
        {
            charInput = getValidatedInput<char>();
        }
        catch (exception e)
        {
            cout<<"Invalid input. Please enter a single letter or number (1 digit)."<<endl;
            continue;
        }

        break;
    }

    return charInput; 
}

string validateString(string &stringInput)
{
    while (true) //use cin, getline() for this 
    {
       // cout << "Enter a word (no spaces): ";

        try
        {
            stringInput  = getValidatedInput<string>();
        }
        catch (exception e)
        {
           cout<<"Invalid input. Please enter a word (no spaces)."<<endl;
            continue;
        }

        break;
    }

    return stringInput; 
}



//function for my menu
void menuChoice(int userInput, scoreboard &s)
{
  string teamName = " ";
  string coachName = " ";
  
  switch(userInput)
      {
        case 1:
        cout << "\n Update Home Team Score: ";
        validateInt(userInput);
        s.home.setScore(userInput);
        break;
        case 2:
        cout << "\n Update Away Team Score: ";
        validateInt(userInput);
        s.away.setScore(userInput);
        break;
        case 3:
        cout << "\n Update Down: "; //has to be less than 4
        validateInt(userInput);
        //check if it is <=3
        while(true){
        if(userInput >0 && userInput <=3)
        {
          s.setDown(userInput);
          break;
        }
        
        else
        {
          cout << "Invalid input. Please enter a number between 1 and 3." << endl;
          validateInt(userInput);
        }}
        break;
        case 4:
        cout << "\n Update To Go: ";
        validateInt(userInput);
        //chek if it is <=10
        while(true)
          {
            if(userInput >0 && userInput <=10)
            {
              s.setToGo(userInput);
              break;
            }
            else
            {
              cout << "Invalid input. Please enter a number between 1 and 10." << endl;
              validateInt(userInput);
            }
          }
        break;
        case 5:
        cout << "\n Update Quarter: ";
        validateInt(userInput);
        //check if it is <=4
        while(true)
          {
            if(userInput >0 && userInput <=4)
            {
              s.setQuarter(userInput);
              break;
            }
            else
            {
              cout << "Invalid input. Please enter a number between 1 and 4." << endl;
              validateInt(userInput);
            }
          }
        break;
        case 6:
        cout << "\n Update Time: ";
        cout<<" \n Minute: ";
        validateInt(userInput);
        while(true){
        if(validateInt(userInput) >= 0 &&validateInt(userInput)<=15)
        {
          s.setMinute(userInput);
        }
        else
        {
          cout << "Invalid input. Please enter a number between 0 and 15." << endl;  
          validateInt(userInput);
        }}
        
        cout<<" \n Second: ";
        validateInt(userInput);
        if(validateInt(userInput) > 0 &&validateInt(userInput)<=59)
        {
          s.setSecond(userInput);
          break;
        }
        else
        {
          cout << "Invalid input. Please enter a number between 0 and 59." << endl;
          validateInt(userInput);
        }
        break;
        case 7:
        cout << "\n Update Home Team Name: ";
        validateString(teamName);
        s.home.setName(teamName);
        break;
        case 8:
        cout << "\n Update Away Team Name: ";
        validateString(teamName);
        s.away.setName(teamName);
        break;
        case 9:
        cout << "\n Update Home Team Coach Name: ";
        validateString(coachName);
        s.home.setCoachName(coachName);
        break;
        case 10:
        cout << "\n Update Away Team Coach Name: ";
        validateString(coachName);
        s.away.setCoachName(coachName);
        break;
        case 11:
        cout << "\n Update Team Possession 1 for HOME and 0 for AWAY : ";
        validateInt(userInput);
        do
          {
            if(userInput == 1)
            {
              s.home.setPossession(true);
              break;
            }
            else if(userInput == 0)
            {
              s.home.setPossession(false);
              break;
            }
            else
            {
              cout << "\n Invalid input. Please enter 1 for HOME or 0 for AWAY: ";
              validateInt(userInput);
            }
          }
        while(userInput >=! 2);
        break;
        //HERE ______________________________________________________________
        case 0:
        cout << "\n Hasta La vista Baby!";
        exit(0);
        break;
        default:
        cout << "\n Invalid Input"<<endl;
        break;

      }


  }

