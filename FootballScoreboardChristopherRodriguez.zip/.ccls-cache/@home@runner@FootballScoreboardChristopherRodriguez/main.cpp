//Christopher Rodriguez

#include <iostream>
#include "functions.h"
using namespace std;
int main() {
  int userInput = 0;
  string teamName = " ";
  scoreboard s;//creates an object of the scoreboard class
  do // time to set our menu.
    { 
      s.showScoreboard();
      cout<<"\n0. Exit"<<endl;
      cout << "\n 1. Update Home Team Score";
      cout << "\n 2. Update Away Team Score";
      cout << "\n 3. Update Down";
      cout << "\n 4. Update To Go";
      cout << "\n 5. Update Quarter";
      cout<<" \n 6. Update Time";
      cout << "\n 7. Update Home Team Name";
      cout << "\n 8. Update Away Team Name";
      cout<<"\n 9. Update Home Coach Name";
      cout<<"\n 10. Update Away Coach Name";
      cout<<"\n 11. Update Ball Possession";
      cout<<"\n Choice: ";
      validateInt(userInput); // make sure our user inputs the right data type (int)
      menuChoice(userInput,s);
    }
    while(userInput!= 0 || userInput != 0);
  return 0;
}